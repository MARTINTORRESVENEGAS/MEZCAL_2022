#!/bin/bash

if [ $1 -gt 100 ]
then
	echo Hey, that is a great number
fi

